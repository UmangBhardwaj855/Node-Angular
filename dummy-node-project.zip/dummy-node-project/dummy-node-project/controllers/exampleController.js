exports.getExample = (req, res) => {
    res.json({ message: 'GET request received for /example' });
};

exports.postExample = (req, res) => {
    const data = req.body;
    res.json({ message: 'POST request received for /example', data });
};
