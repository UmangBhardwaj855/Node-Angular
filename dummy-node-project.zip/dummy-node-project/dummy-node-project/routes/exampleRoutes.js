const express = require('express');
const router = express.Router();
const { getExample, postExample } = require('../controllers/exampleController');

// Define routes
router.get('/example', getExample);
router.post('/example', postExample);

module.exports = router;
