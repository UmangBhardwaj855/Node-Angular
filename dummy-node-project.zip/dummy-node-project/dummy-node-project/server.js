// Import necessary modules
const express = require('express');
const axios = require('axios');
const { Sequelize, DataTypes } = require('sequelize');
const swaggerUi = require('swagger-ui-express');
const swaggerJsDoc = require('swagger-jsdoc');
const winston = require('winston');
const cors = require('cors');

// Constants
const API_URL = 'https://dummyjson.com/recipes';
const PORT = 3000;
const RETRY_LIMIT = 3;

// Initialize application
const app = express();
app.use(express.json());
app.use(cors());

// Logger configuration
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [new winston.transports.Console()]
});

// Database setup (H2 in-memory using Sequelize)
const sequelize = new Sequelize('sqlite::memory:', {
  logging: false
});

const Recipe = sequelize.define('Recipe', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  cuisine: {
    type: DataTypes.STRING,
    allowNull: false
  },
  caloriesPerServing: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  image: {
    type: DataTypes.STRING,
    allowNull: true
  },
  ingredients: {
    type: DataTypes.TEXT,
    allowNull: false
  }
}, {
  timestamps: false
});

const swaggerOptions = {
  swaggerDefinition: {
    openapi: '3.0.0',
    info: {
      title: 'Recipes API',
      version: '1.0.0',
      description: 'API to manage recipes stored in an in-memory database'
    },
    servers: [{ url: `http://localhost:${PORT}` }]
  },
  apis: ['./server.js']
};
const swaggerDocs = swaggerJsDoc(swaggerOptions);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs));

async function fetchRecipesWithRetry(url, retries = RETRY_LIMIT) {
  while (retries > 0) {
    try {
      const response = await axios.get(url);
      return response.data.recipes;
    } catch (error) {
      logger.error(`Error fetching data: ${error.message}`);
      retries -= 1;
      if (retries === 0) throw new Error('Failed to fetch data after retries');
      logger.info(`Retrying... attempts left: ${retries}`);
    }
  }
}

    // app.use('/', async (req, res) => {
    // let config = {
    //   method: 'get',
    //   maxBodyLength: Infinity,
    //   url: API_URL,
    //   headers: { }
    // };
    
    // axios.request(config)
    // .then((response) => {
    //   console.log(JSON.parse(JSON.stringify(response.data)));
    // })
    // .catch((error) => {
    //   console.log(error);
    // });


    // })

// Endpoint to get all available recipes
/**
 * @swagger
 * /recipes:
 *   get:
 *     summary: Retrieve all recipes
 *     responses:
 *       200:
 *         description: List of all recipes
 */
// app.get('/recipes', async (req, res) => {
//   try {
//     const recipes = await Recipe.findAll();
//     res.json(recipes);
//   } catch (err) {
//     logger.error(`Failed to fetch recipes: ${err.message}`);
//     res.status(500).send('Failed to fetch recipes');
//   }
// });
app.get('/recipes', async (req, res) => {
  try {
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: API_URL,
      headers: {}
    };

    const response = await axios.request(config);
    const data = response.data.recipes.map(recipe => ({
      id: recipe.id,
      name: recipe.name,
      tags: recipe.tags,
      mealType: recipe.mealType,
      instructions: recipe.instructions,
      ingredients: recipe.ingredients
    }));

    if (!data.length) {
      return res.status(404).send('No recipes found');
    }

    res.json(data);
  } catch (err) {
    logger.error(`Failed to fetch all recipes: ${err.message}`);
    res.status(500).send('An error occurred while fetching recipes');
  }
});


// Endpoint to get recipes by cuisine
/**
 * @swagger
 * /recipes/cuisine/{cuisine}:
 *   get:
 *     summary: Retrieve recipes by cuisine
 *     parameters:
 *       - in: path
 *         name: cuisine
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: List of recipes for a specific cuisine
 */
// app.get('/recipes/cuisine/:cuisine', async (req, res) => {
//   const cuisine = req.params.cuisine;
//   try {
//     const recipes = await Recipe.findAll({ where: { cuisine } });
//     res.json(recipes);
//   } catch (err) {
//     logger.error(`Failed to fetch recipes by cuisine: ${err.message}`);
//     res.status(500).send('Failed to fetch recipes');
//   }
// });
app.get('/recipes/cuisine/:cuisine', async (req, res) => {
  const cuisine = req.params.cuisine;
  try {
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: API_URL,
      headers: {}
    };

    const response = await axios.request(config);
    const filteredRecipes = response.data.recipes.filter(recipe => recipe.cuisine === cuisine).map(recipe => ({
      id: recipe.id,
      name: recipe.name,
      tags: recipe.tags,
      mealType: recipe.mealType,
      instructions: recipe.instructions,
      ingredients: recipe.ingredients
    }));

    if (!filteredRecipes.length) {
      return res.status(404).send(`No recipes found for cuisine: ${cuisine}`);
    }

    res.json(filteredRecipes);
  } catch (err) {
    logger.error(`Failed to fetch recipes by cuisine: ${err.message}`);
    res.status(500).send('An error occurred while fetching recipes by cuisine');
  }
});


// Endpoint to get recipes sorted by calories
/**
 * @swagger
 * /recipes/sort:
 *   get:
 *     summary: Retrieve recipes sorted by calories
 *     parameters:
 *       - in: query
 *         name: order
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *     responses:
 *       200:
 *         description: List of recipes sorted by calories per serving
 */
// app.get('/recipes/sort', async (req, res) => {
//   const order = req.query.order === 'desc' ? 'DESC' : 'ASC';
//   try {
//     const recipes = await Recipe.findAll({ order: [['caloriesPerServing', order]] });
//     res.json(recipes);
//   } catch (err) {
//     logger.error(`Failed to fetch sorted recipes: ${err.message}`);
//     res.status(500).send('Failed to fetch recipes');
//   }
// });
app.get('/recipes/sort', async (req, res) => {
  const order = req.query.order === 'desc' ? 'desc' : 'asc';
  try {
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: API_URL,
      headers: {}
    };

    const response = await axios.request(config);
    const sortedRecipes = response.data.recipes.sort((a, b) => {
      return order === 'asc'
        ? a.caloriesPerServing - b.caloriesPerServing
        : b.caloriesPerServing - a.caloriesPerServing;
    }).map(recipe => ({
      id: recipe.id,
      name: recipe.name,
      tags: recipe.tags,
      mealType: recipe.mealType,
      instructions: recipe.instructions,
      ingredients: recipe.ingredients
    }));

    if (!sortedRecipes.length) {
      return res.status(404).send('No recipes found');
    }

    res.json(sortedRecipes);
  } catch (err) {
    logger.error(`Failed to fetch sorted recipes: ${err.message}`);
    res.status(500).send('An error occurred while fetching sorted recipes');
  }
});


// Endpoint to find a specific recipe by ID
/**
 * @swagger
 * /recipes/{id}:
 *   get:
 *     summary: Retrieve a specific recipe by ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: The details of a specific recipe
 */
app.get('/recipes/:id', async (req, res) => {
  const id = req.params.id;
  var k=[]
  try {
    console.log("sdlkfjhfgsdjfgsjgfjh")
    // const recipe = await Recipe.findByPk(id);
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: API_URL,
      headers: { }
    };
    
    axios.request(config)
    .then((response) => {
      let c=JSON.parse(JSON.stringify(response.data))
      // console.log(c);
     
      c?.recipes.forEach(d=>{
        k.push({
        name:d.name,
        tag:d.tags,
        mealType:d.mealType,
        instructions:d.instructions,
        ingredients:d.ingredients
      })
      })
      // console.log(k)

      if (!k) {
        res.status(404).send('Recipe not found');
      } else {
        console.log("kk",k)
        res.send(k);
      }
    })
   
  } catch (err) {
    logger.error(`Failed to fetch recipe: ${err.message}`);
    res.status(500).send('Failed to fetch recipe');
  }
});

sequelize.sync().then(() => {
    app.listen(PORT, () => {
      logger.info(`Server is running on http://localhost:${PORT}`);
      logger.info(`Swagger docs available at http://localhost:${PORT}/api-docs`);

     
    });
  }).catch((error) => {
    logger.error(`Failed to synchronize database: ${error.message}`);
  });
  
