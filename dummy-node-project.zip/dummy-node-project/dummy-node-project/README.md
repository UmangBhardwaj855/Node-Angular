# Dummy Node.js Project

This is a simple Node.js project using Express. It demonstrates basic routing and controller logic.

## Features
- Basic GET and POST API routes
- Modular project structure
- Easy to extend

## Requirements
- Node.js
- npm

## Setup

1. Clone the repository or download the source code.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the server:
   ```bash
   npm start
   ```
4. Open your browser or use Postman to test:
   - `GET /api/example` - Returns a sample message.
   - `POST /api/example` - Accepts JSON data and returns it.

## License
MIT
